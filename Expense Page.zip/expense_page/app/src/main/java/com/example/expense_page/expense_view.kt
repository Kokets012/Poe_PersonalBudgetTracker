package com.example.expense_page

import android.app.DatePickerDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Toast
import com.google.android.material.snackbar.Snackbar
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.expense_page.databinding.ActivityExpenseViewBinding
import com.example.expense_page.databinding.ExpenseItemBinding
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale


class expense_view : AppCompatActivity() {

    private lateinit var binding: ActivityExpenseViewBinding
    private lateinit var expensesAdapter: ExpensesAdapter
    private val calendar = Calendar.getInstance()
    private val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())

    companion object {
        val expensesList = mutableListOf<Expense>()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityExpenseViewBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupRecyclerView()
        setupDatePicker()
        setupSaveButton()
    }

    private fun setupRecyclerView() {
        expensesAdapter = ExpensesAdapter(expensesList)
        binding.rvExpenses.apply {
            layoutManager = LinearLayoutManager(this@expense_view)
            adapter = expensesAdapter
        }
    }

    private fun setupDatePicker() {
        val dateSetListener = DatePickerDialog.OnDateSetListener { _, year, month, day ->
            calendar.set(Calendar.YEAR, year)
            calendar.set(Calendar.MONTH, month)
            calendar.set(Calendar.DAY_OF_MONTH, day)
            updateDateButton()
        }

        binding.btnDate.setOnClickListener {
            DatePickerDialog(
                this,
                dateSetListener,
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
            ).show()
        }
    }

    private fun updateDateButton() {
        binding.btnDate.text = dateFormat.format(calendar.time)
    }

    private fun setupSaveButton() {
        binding.btnSave.setOnClickListener {
            if (validateInput()) {
                saveExpense()
            }
        }
    }

    private fun validateInput(): Boolean {
        return when {
            binding.etName.text.toString().trim().isEmpty() -> {
                showToast("Please enter name")
                false
            }
            binding.etCategory.text.toString().trim().isEmpty() -> {
                showToast("Please enter category")
                false
            }
            binding.etAmount.text.toString().trim().isEmpty() -> {
                showToast("Please enter amount")
                false
            }
            binding.btnDate.text.toString() == "Select Date" -> {
                showToast("Please select date")
                false
            }
            else -> true
        }
    }

    private fun saveExpense() {
        val amount = try {
            NumberFormat.getNumberInstance().parse(binding.etAmount.text.toString())?.toDouble()
        } catch (e: Exception) {
            null
        }

        val expense = Expense(
            name = binding.etName.text.toString().trim(),
            category = binding.etCategory.text.toString().trim(),
            amount = amount ?: 0.0,
            date = dateFormat.format(calendar.time),
            description = binding.etDescription.text.toString().trim()
        )

        expensesList.add(expense)
        expensesAdapter.notifyItemInserted(expensesList.size - 1)
        showToast("Expense saved!")
        clearForm()
    }

    private fun clearForm() {
        binding.etName.text?.clear()
        binding.etCategory.text?.clear()
        binding.etAmount.text?.clear()
        binding.etDescription.text?.clear()
        binding.btnDate.text = "Select Date"
        calendar.timeInMillis = System.currentTimeMillis()
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    data class Expense(
        val name: String,
        val category: String,
        val amount: Double,
        val date: String,
        val description: String
    )

    class ExpensesAdapter(private val expenses: List<Expense>) :
        RecyclerView.Adapter<ExpensesAdapter.ViewHolder>() {

        class ViewHolder(val binding: ExpenseItemBinding) : RecyclerView.ViewHolder(binding.root)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            val binding = ExpenseItemBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
            return ViewHolder(binding)
        }

        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            val expense = expenses[position]
            with(holder.binding) {
                tvName.text = expense.name
                tvCategory.text = expense.category
                tvAmount.text = "R${"%.2f".format(expense.amount)}"
                tvDate.text = expense.date
                tvDescription.text = expense.description
            }
        }

        override fun getItemCount() = expenses.size
    }
}