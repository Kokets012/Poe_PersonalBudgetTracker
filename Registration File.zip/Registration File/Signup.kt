package com.example.appi

import android.content.Intent
import android.os.Bundle
import android.util.Patterns
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.appi.databinding.ActivitySignupBinding
import java.util.regex.Pattern

class Signup : AppCompatActivity() {
    private lateinit var binding: ActivitySignupBinding

    // At least 8 characters, one uppercase, one lowercase, one digit, one special character
    private val PASSWORD_PATTERN = Pattern.compile(
        "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=!])(?=\\S+$).{8,}$"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySignupBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setupClickListeners()
    }

    private fun setupClickListeners() {
        binding.btnSignup.setOnClickListener { handleSignup() }
        binding.tvLogin.setOnClickListener { navigateToLogin() }

        // Add password strength indicator
        binding.etPassword.setOnFocusChangeListener { _, hasFocus ->
            if (!hasFocus && !binding.etPassword.text.isNullOrEmpty()) {
                validatePasswordStrength(binding.etPassword.text.toString())
            }
        }
    }

    private fun handleSignup() {
        if (!validateInput()) return

        val username = binding.etUsername.text.toString()
        val email = binding.etEmail.text.toString()
        val password = binding.etPassword.text.toString()

        // Hash the password before storing
        val hashedPassword = PasswordUtils.hashPassword(password)

        when {
            AuthRepository.signUp(username, email, hashedPassword) -> {
                showSignupSuccess()
                navigateToLogin()
            }
            else -> showEmailRegisteredError()
        }
    }

    private fun validateInput(): Boolean {
        var isValid = true

        with(binding) {
            // Username validation
            if (etUsername.text.isNullOrBlank()) {
                etUsername.error = "Username is required"
                isValid = false
            } else if (etUsername.text.toString().length < 4) {
                etUsername.error = "Username must be at least 4 characters"
                isValid = false
            }

            // Email validation
            if (etEmail.text.isNullOrBlank()) {
                etEmail.error = "Email is required"
                isValid = false
            } else if (!isValidEmail(etEmail.text.toString())) {
                etEmail.error = "Please enter a valid email address"
                isValid = false
            }

            // Password validation
            if (etPassword.text.isNullOrBlank()) {
                etPassword.error = "Password is required"
                isValid = false
            } else if (!isValidPassword(etPassword.text.toString())) {
                // Error message set in validatePasswordStrength
                isValid = false
            }

            // Confirm password validation
            if (etConfirmPassword.text.isNullOrBlank()) {
                etConfirmPassword.error = "Please confirm your password"
                isValid = false
            } else if (etPassword.text.toString() != etConfirmPassword.text.toString()) {
                etConfirmPassword.error = "Passwords don't match"
                isValid = false
            }
        }

        return isValid
    }

    private fun isValidEmail(email: String): Boolean {
        return Patterns.EMAIL_ADDRESS.matcher(email).matches()
    }

    private fun isValidPassword(password: String): Boolean {
        return PASSWORD_PATTERN.matcher(password).matches()
    }

    private fun validatePasswordStrength(password: String) {
        when {
            password.length < 8 -> {
                binding.etPassword.error = "Password must be at least 8 characters"
            }
            !password.any { it.isDigit() } -> {
                binding.etPassword.error = "Password must contain at least one digit"
            }
            !password.any { it.isUpperCase() } -> {
                binding.etPassword.error = "Password must contain at least one uppercase letter"
            }
            !password.any { it.isLowerCase() } -> {
                binding.etPassword.error = "Password must contain at least one lowercase letter"
            }
            !password.any { !it.isLetterOrDigit() } -> {
                binding.etPassword.error = "Password must contain at least one special character"
            }
            else -> {
                binding.etPassword.error = null
                Toast.makeText(this, "Password strength: Good", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun showSignupSuccess() {
        Toast.makeText(this, "Signup successful!", Toast.LENGTH_SHORT).show()
    }

    private fun showEmailRegisteredError() {
        Toast.makeText(this, "Email already registered", Toast.LENGTH_SHORT).show()
    }

    private fun navigateToLogin() {
        startActivity(Intent(this, LoginActivity::class.java))
        finish()
    }
}

object PasswordUtils {
    // In a real app, use proper password hashing like BCrypt
    fun hashPassword(password: String): String {
        // TODO: Replace with proper hashing algorithm (e.g., BCrypt)
        // This is just a placeholder - NEVER use this in production
        return "hashed_${password.hashCode()}"
    }
}