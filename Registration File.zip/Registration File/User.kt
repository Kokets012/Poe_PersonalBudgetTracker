package com.example.appi

data class User(
    val id: Int,
    val username: String,
    val email: String,
    val password: String
)