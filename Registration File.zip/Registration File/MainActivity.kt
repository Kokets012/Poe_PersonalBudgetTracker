package com.example.appi

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.appi.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    companion object {
        private const val PREFS_NAME = "AppPrefs"
        private const val CURRENT_USER_ID = "CURRENT_USER_ID"
        private const val INVALID_USER_ID = -1
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val sharedPref = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val userId = sharedPref.getInt(CURRENT_USER_ID, INVALID_USER_ID)

        // Handle user authentication state
        when {
            userId == INVALID_USER_ID -> {
                redirectToLogin()
                return
            }
            else -> loadUserData(userId)
        }

        setupLogoutButton(sharedPref)
    }

    private fun loadUserData(userId: Int) {
        AuthRepository.getUserById(userId)?.let { user ->
            binding.apply {
                tvWelcome.text = "Welcome, ${user.username}!"
                tvEmail.text = "Email: ${user.email}"
            }
        } ?: run {
            showUserNotFound()
        }
    }

    private fun showUserNotFound() {
        Toast.makeText(this, "User not found", Toast.LENGTH_SHORT).show()
        redirectToLogin()
    }

    private fun redirectToLogin() {
        startActivity(Intent(this, LoginActivity::class.java))
        finish()
    }

    private fun setupLogoutButton(sharedPref: SharedPreferences) {
        binding.btnLogout.setOnClickListener {
            sharedPref.edit().remove(CURRENT_USER_ID).apply()
            redirectToLogin()
        }
    }
}