package com.example.appi

import android.annotation.SuppressLint
import android.util.Patterns
import java.security.MessageDigest
import java.util.*

object AuthRepository {
    private val users = mutableListOf<User>()
    private var nextId = 1

    // Password requirements
    private const val MIN_PASSWORD_LENGTH = 8
    private val PASSWORD_PATTERN = Regex("^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z]).{8,}$")

    fun signUp(username: String, email: String, password: String): Boolean {
        // Validate inputs
        when {
            username.isBlank() -> throw IllegalArgumentException("Username cannot be empty")
            !isValidEmail(email) -> throw IllegalArgumentException("Invalid email format")
            !isValidPassword(password) -> throw IllegalArgumentException(
                "Password must contain at least $MIN_PASSWORD_LENGTH characters, " +
                        "including uppercase, lowercase and numbers"
            )
            users.any { it.email == email } -> return false
        }

        val newUser = User(
            id = nextId++,
            username = username.trim(),
            email = email.trim().lowercase(),
            password = hashPassword(password)
        )
        users.add(newUser)
        return true
    }

    fun login(email: String, password: String): User? {
        val cleanEmail = email.trim().lowercase()
        val hashedPassword = hashPassword(password)

        return users.find {
            it.email == cleanEmail && it.password == hashedPassword
        }
    }

    fun getUserById(id: Int): User? {
        return users.find { it.id == id }
    }

    private fun isValidEmail(email: String): Boolean {
        return Patterns.EMAIL_ADDRESS.matcher(email).matches()
    }

    private fun isValidPassword(password: String): Boolean {
        return password.length >= MIN_PASSWORD_LENGTH &&
                PASSWORD_PATTERN.matches(password)
    }

    @SuppressLint("NewApi")
    private fun hashPassword(password: String): String {
        return try {
            val digest = MessageDigest.getInstance("SHA-256")
            val hash = digest.digest(password.toByteArray(Charsets.UTF_8))
            Base64.getEncoder().encodeToString(hash)
        } catch (e: Exception) {
            throw RuntimeException("Failed to hash password", e)
        }
    }

    // For testing/reset purposes
    internal fun clearAllUsers() {
        users.clear()
        nextId = 1
    }
}